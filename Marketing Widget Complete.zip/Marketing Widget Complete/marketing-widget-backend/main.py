from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import json
import uuid

app = FastAPI()

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

WIDGET_FILE = "widget.json"
CLICK_LOG_FILE = "clicks.json"
FEEDBACK_FILE = "feedback_log.json"

class Widget(BaseModel):
    id: str
    type: str
    emoji: str
    text: str
    start_datetime: str
    end_datetime: str
    common_animation: Optional[bool] = True
    animation: Optional[str] = None
    animation_desktop: Optional[str] = None
    animation_mobile: Optional[str] = None
    manual_override: Optional[bool] = None

class ClickLog(BaseModel):
    widget_id: str
    action: str
    text: Optional[str] = ""

def read_widgets():
    try:
        with open(WIDGET_FILE, "r") as f:
            return json.load(f)
    except:
        return []

def write_widgets(widgets):
    with open(WIDGET_FILE, "w") as f:
        json.dump(widgets, f, indent=2)

@app.get("/widgets", response_model=List[Widget])
def get_widgets():
    return read_widgets()

@app.get("/widget", response_model=List[Widget])
def get_enabled_widgets():
    widgets = read_widgets()
    return [w for w in widgets if w.get("manual_override", None) is not False]

@app.post("/widgets", response_model=Widget)
def create_widget(widget: Widget):
    widgets = read_widgets()
    widgets.append(widget.dict())
    write_widgets(widgets)
    return widget

@app.put("/widgets/{widget_id}", response_model=Widget)
def update_widget(widget_id: str, updated_widget: Widget):
    widgets = read_widgets()
    for i, w in enumerate(widgets):
        if w["id"] == widget_id:
            widgets[i] = updated_widget.dict()
            write_widgets(widgets)
            return updated_widget
    raise HTTPException(status_code=404, detail="Widget not found")

@app.delete("/widgets/{widget_id}")
def delete_widget(widget_id: str):
    widgets = read_widgets()
    new_widgets = [w for w in widgets if w["id"] != widget_id]
    write_widgets(new_widgets)
    return {"detail": "Deleted"}

@app.patch("/widgets/{widget_id}/toggle")
def toggle_manual_override(widget_id: str):
    widgets = read_widgets()
    for widget in widgets:
        if widget["id"] == widget_id:
            current = widget.get("manual_override", None)
            widget["manual_override"] = not current if current is not None else True
            write_widgets(widgets)
            return {"manual_override": widget["manual_override"]}
    raise HTTPException(status_code=404, detail="Widget not found")

@app.post("/track_click")
def track_click(log: ClickLog):
    try:
        with open(CLICK_LOG_FILE, "r") as f:
            data = json.load(f)
    except:
        data = []
    data.append(log.dict())
    with open(CLICK_LOG_FILE, "w") as f:
        json.dump(data, f, indent=2)
    return {"detail": "Logged"}

@app.get("/clicks")
def get_clicks():
    try:
        with open(CLICK_LOG_FILE, "r") as f:
            return json.load(f)
    except:
        return []

@app.get("/feedback")
def get_feedback():
    try:
        with open(FEEDBACK_FILE, "r") as f:
            return json.load(f)
    except:
        return []

@app.post("/feedback")
def save_feedback(feedback: ClickLog):
    try:
        with open(FEEDBACK_FILE, "r") as f:
            data = json.load(f)
    except:
        data = []
    data.append(feedback.dict())
    with open(FEEDBACK_FILE, "w") as f:
        json.dump(data, f, indent=2)
    return {"detail": "Feedback saved"}
