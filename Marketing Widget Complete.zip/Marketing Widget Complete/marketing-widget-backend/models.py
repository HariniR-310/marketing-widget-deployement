from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Widget(BaseModel):
    content: str
    start_time: datetime
    end_time: datetime
    visible: bool = True
