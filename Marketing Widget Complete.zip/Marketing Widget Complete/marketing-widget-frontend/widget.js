async function loadWidgets() {
  const res = await fetch("http://127.0.0.1:8000/widgets");
  const widgets = await res.json();
  const now = new Date();

  widgets.forEach(widget => {
    const start = new Date(widget.start_datetime);
    const end = new Date(widget.end_datetime);

    console.log(`[${widget.type}] Start: ${start}, End: ${end}, Override: ${widget.manual_override}`);

    const shouldShow =
      widget.manual_override === true ||
      (widget.manual_override === null && now >= start && now <= end);

    if (shouldShow) {
      console.log("✅ Showing widget:", widget);
      showWidget(widget);
    } else {
      console.log("⏭️ Skipping widget:", widget.text);
    }
  });
}

function showWidget(widget) {
  if (widget.type === "popup") {
    const popup = document.createElement("div");
    popup.className = "widget-popup";
    popup.innerHTML = `
      <button class="widget-popup-close" onclick="this.parentElement.remove()">×</button>
      <strong>${widget.emoji || ""}</strong> ${widget.text}
    `;
    document.body.appendChild(popup);
  }

  else if (widget.type === "banner") {
    const banner = document.createElement("div");
    banner.className = "widget-banner";
    banner.textContent = `${widget.emoji || ""} ${widget.text}`;
    document.body.prepend(banner);
  }

  else if (widget.type === "feedback") {
    setTimeout(() => {
      const box = document.createElement("div");
      box.className = "widget-feedback";
      box.innerHTML = `
        <h3>${widget.emoji || "📝"} Feedback</h3>
        <textarea placeholder="Your thoughts..."></textarea>
        <button onclick="submitFeedback(this)">Send</button>
      `;
      document.body.appendChild(box);
    }, 30000); // 30 sec delay
  }
}

function submitFeedback(btn) {
  const textarea = btn.previousElementSibling;
  const feedback = textarea.value.trim();
  if (feedback) {
    console.log("📩 Feedback submitted:", feedback);
    alert("Thank you for your feedback!");
    btn.closest(".widget-feedback").remove();
  } else {
    alert("Please write something before submitting.");
  }
}

// Inject CSS styles with dashboard theme
(function applyWidgetStyles() {
  const style = document.createElement("style");
  style.innerHTML = `
    :root {
      --blue: #2d90b0;
      --cream: #f3fff9;
    }

    body {
      background-color: var(--cream);
      font-family: 'Segoe UI', sans-serif;
    }

    .widget-popup {
      position: fixed;
      top: 20px;
      right: 20px;
      background-color: white;
      border-left: 6px solid var(--blue);
      padding: 16px 20px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.15);
      max-width: 300px;
      z-index: 1000;
    }

    .widget-popup-close {
      position: absolute;
      top: 6px;
      right: 10px;
      background: none;
      border: none;
      font-size: 16px;
      cursor: pointer;
      color: #666;
    }

    .widget-banner {
      background-color: var(--blue);
      color: white;
      text-align: center;
      padding: 12px;
      font-size: 18px;
      font-weight: 500;
      position: relative;
      z-index: 999;
    }

    .widget-feedback {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border: 2px solid var(--blue);
      padding: 24px;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.1);
      z-index: 999;
      max-width: 400px;
      width: 90%;
    }

    .widget-feedback h3 {
      margin-top: 0;
      color: var(--blue);
      font-size: 20px;
    }

    .widget-feedback textarea {
      width: 100%;
      height: 100px;
      border: 1px solid #ccc;
      padding: 10px;
      border-radius: 6px;
      margin-top: 10px;
      resize: vertical;
      font-size: 14px;
    }

    .widget-feedback button {
      margin-top: 12px;
      background-color: var(--blue);
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
    }

    .widget-feedback button:hover {
      background-color: #257893;
    }
  `;
  document.head.appendChild(style);
})();

// Load widgets now
loadWidgets();
