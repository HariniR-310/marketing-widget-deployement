document.addEventListener("DOMContentLoaded", async () => {
  const res = await fetch("http://127.0.0.1:8000/widget");
  const widgets = await res.json();

  const popup = widgets.find(w => w.type === "popup");
  const feedback = widgets.find(w => w.type === "feedback");

  function createWidgetElement(widget) {
    const container = document.createElement("div");
    container.className = "widget " + widget.type;
    container.style.position = "fixed";
    container.style.zIndex = "9999";
    container.style.background = "#fff";
    container.style.border = "1px solid #ccc";
    container.style.borderRadius = "8px";
    container.style.boxShadow = "0 4px 10px rgba(0,0,0,0.1)";
    container.style.padding = "16px";
    container.style.display = "flex";
    container.style.alignItems = "center";
    container.style.justifyContent = "space-between";
    container.style.minWidth = "250px";

    const message = document.createElement("span");
    message.textContent = widget.emoji + " " + widget.text;
    container.appendChild(message);

    const closeBtn = document.createElement("button");
    closeBtn.textContent = "X";
    closeBtn.style.marginLeft = "12px";
    closeBtn.style.cursor = "pointer";
    closeBtn.onclick = () => {
      container.remove();
      trackClick(widget.id, "dismissed");
      if (widget.type === "popup" && feedback) {
        setTimeout(() => showWidget(feedback), 30000); // show feedback after 30s
      }
    };
    container.appendChild(closeBtn);

    if (widget.type === "popup") {
      container.style.bottom = "20px";
      container.style.right = "20px";
    } else if (widget.type === "feedback") {
      container.style.top = "50%";
      container.style.left = "50%";
      container.style.transform = "translate(-50%, -50%)";
    }

    document.body.appendChild(container);
    trackClick(widget.id, "displayed");
  }

  function showWidget(widget) {
    createWidgetElement(widget);
  }

  function trackClick(widget_id, action) {
    fetch("http://127.0.0.1:8000/track_click", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ widget_id, action })
    });
  }

  if (popup) {
    showWidget(popup);
  } else if (feedback) {
    setTimeout(() => showWidget(feedback), 30000);
  }
});
